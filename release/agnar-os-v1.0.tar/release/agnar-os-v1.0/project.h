/**
 * Martin Wuerms
 * 2015-08-10
 *
 * - this file contains architecture specific definitions etc ... -
 */

#ifndef _PROJECT_H_
#define _PROJECT_H_

/* - includes --------------------------------------------------------------- */
#include "arch.h"
#include "version.h"

/* - typedef ---------------------------------------------------------------- */

/* - public functions ------------------------------------------------------- */


#endif /* _ARCH_H_ */
